import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class tic extends Frame implements ActionListener {
	JPanel P1 = new JPanel();
	JButton b1 = new JButton("1");
	JButton b2 = new JButton("2");
	JButton b3 = new JButton("3");
	JButton b4 = new JButton("4");
	JButton b5 = new JButton("5");
	JButton b6 = new JButton("6");
	JButton b7 = new JButton("7");
	JButton b8 = new JButton("8");
	JButton b9 = new JButton("9");
	int i = 0;

	tic() {

		P1.add(b1);
		P1.add(b2);
		P1.add(b3);
		P1.add(b4);
		P1.add(b5);
		P1.add(b6);
		P1.add(b7);
		P1.add(b8);
		P1.add(b9);
		P1.setLayout(new GridLayout(3, 3));
		add(P1);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		b7.addActionListener(this);
		b8.addActionListener(this);
		b9.addActionListener(this);
		addWindowListener(new fermer());
		this.setSize(500, 500);
		b1.setFocusable(false);
		b2.setFocusable(false);
		b3.setFocusable(false);
		b4.setFocusable(false);
		b5.setFocusable(false);
		b6.setFocusable(false);
		b7.setFocusable(false);
		b8.setFocusable(false);
		b9.setFocusable(false);
		// pack();
		setVisible(true);

	}

	void win(JButton x, JButton y, JButton z) {
		System.out.println("GAME OVER");
		x.setBackground(Color.green);
		y.setBackground(Color.green);
		z.setBackground(Color.green);
		JPanel p = new JPanel();
		JLabel label = new JLabel();
		JFrame fr = new JFrame();
		fr.setSize(500, 500);

		String sj = x.getText();

		label.setText(sj + " WINS");
		label.setFont(new Font("Arial", Font.PLAIN, 40));
		label.setHorizontalTextPosition(JLabel.CENTER);
		fr.add(label);
		// setVisible(false);
		fr.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (i % 2 == 0) {
			((JButton) e.getSource()).setText("X");
			((JButton) e.getSource()).setFont(new Font("Dialog", Font.PLAIN, 100));

			((JButton) e.getSource()).setEnabled(false);

			i++;
		} else {
			((JButton) e.getSource()).setText("O");
			((JButton) e.getSource()).setFont(new Font("Dialog", Font.PLAIN, 100));

			((JButton) e.getSource()).setEnabled(false);
			i++;

		}
		if (b1.getText() == b2.getText() && b3.getText() == b2.getText())

		{
			win(b1, b2, b3);
		}

		if (b1.getText() == b4.getText() && b1.getText() == b7.getText()) {

			win(b1, b4, b7);
		}

		if (b5.getText() == b2.getText() && b8.getText() == b2.getText()) {

			win(b2, b5, b8);
		}

		if (b3.getText() == b6.getText() && b3.getText() == b9.getText()) {

			win(b6, b3, b9);
		}

		if (b4.getText() == b5.getText() && b4.getText() == b6.getText()) {

			win(b4, b5, b6);
		}

		if (b7.getText() == b8.getText() && b9.getText() == b7.getText()) {

			win(b9, b7, b8);
		}

		if (b1.getText() == b5.getText() && b9.getText() == b5.getText()) {

			win(b1, b5, b9);
		}

		if (b3.getText() == b5.getText() && b3.getText() == b7.getText()) {

			win(b3, b5, b7);
		}
	}

	public static void main(String args[]) {
		tic t = new tic();
	}

}
